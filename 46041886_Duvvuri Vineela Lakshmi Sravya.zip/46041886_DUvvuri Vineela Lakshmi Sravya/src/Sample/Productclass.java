package Sample;

public class Productclass {
	Productclass()
	{
		this("Rice",1000.0);
		System.out.println("No parameter");
	}
	Productclass(String prod)
	{
		this();
		System.out.println("The item is "+prod);
	}
	Productclass(String prod, double price)
	{
		//this("Salt"); // Recursive
		System.out.println(prod+" price is "+price);
	}
	public static void main(String[] args)
	{
		Productclass obj=new Productclass("Sugar");
	}
}
// This is called constructor chaining.
// Execution from line 21 -->9-->4-->14