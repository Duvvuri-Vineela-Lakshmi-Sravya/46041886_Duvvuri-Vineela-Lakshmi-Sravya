package Sample;

public class CinemaHall {
	static double cost=120.0;
	int no_persons;
	
	//CinemaHall obj2=new CinemaHall(); // we can make obj2 static to access in class.
	
	static CinemaHall obj3=new CinemaHall();
	static void display()
	{
		CinemaHall obj=new CinemaHall();
		obj.setNo_persons(6);
		System.out.println("ITS MOVIE TIME");
		System.out.println("Total fare for "+obj.getNo_persons()+" is "+obj.calculate());
		//System.out.println("Total fare for "+obj.obj2.getNo_persons()+" is "+obj.obj2.calculate());
		System.out.println("Total fare for "+obj3.getNo_persons()+" is "+obj3.calculate());
		
	}
	double calculate() // static double calculate() will give error
	// 
	{
		return this.getNo_persons()*cost;
	}
	
	public int getNo_persons() {
		return no_persons;
	}

	public void setNo_persons(int no_persons) {
		this.no_persons = no_persons;
	}

	public static void main(String[] args)
	{
		//CinemaHall obj=new CinemaHall();
		CinemaHall obj1=new CinemaHall();
		
		//obj.setNo_persons(6);
		obj1.setNo_persons(16);
		
		//obj1.obj2.setNo_persons(20);
		
		obj3.setNo_persons(10);
		
		display();
		
		System.out.println("Total fare for "+obj1.getNo_persons()+" is "+obj1.calculate());
		
		
	}
}

// creating objects is also scope based.We cannot use the object created in one function into other function.
