package Sample;

public class ObjectClassMethods {
	public static void main(String[] args)
	{
		ObjectClassMethods obm=new ObjectClassMethods();
		ObjectClassMethods obm1=new ObjectClassMethods();
		System.out.println("The class is "+obm.getClass());
		int objcode=obm.hashCode();
		System.out.println("The hashcode of the object is "+objcode);
		System.out.println("The two objects are equal : "+obm.equals(obm1));
		//System.out.println("The clone of the object is created"+obm.clone()); created an exception.
		
		//obm.notify();
		
	}

}
