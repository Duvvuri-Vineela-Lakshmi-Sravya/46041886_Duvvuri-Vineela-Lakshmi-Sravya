package Sample;

public class SystemClass {
	
	public static void main(String[] args)
	{
		System.out.println("The current time in milliseconds is "+System.currentTimeMillis());
		// It will give the difference value from current time to Jan1 1970
	}
}
