package Sample;

public class EnumClass {
	
	public static void main(String[] args)
	{
		int i;
	EnumSample e1=EnumSample.JAN;  // Constructor ?
	System.out.println(e1);
	e1.display();
	EnumSample e2=EnumSample.FEB; // constructor ?
	System.out.println(e2); // e1+e2 ?
	// EnumSample e3=EnumSample.APR+EnumSample.AUG;
	EnumSample e[]=EnumSample.values();
	for(i=0;i<e.length;i++) {
		System.out.println("The value of "+e[i]+" is "+e[i].ordinal()); // ordinal gives the numeric value
	}	
	}
}
