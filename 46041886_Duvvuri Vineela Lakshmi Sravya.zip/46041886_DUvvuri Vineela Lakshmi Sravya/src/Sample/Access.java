package Sample;

public class Access {
private int a=10,b=20;
public static void main(String[] args)
{
	Access access = new Access();
	System.out.println("The sum is "+(access.a+access.b));
}
}
class Access123
{
	void display()
	{
		System.out.println("A new class");
	}
}