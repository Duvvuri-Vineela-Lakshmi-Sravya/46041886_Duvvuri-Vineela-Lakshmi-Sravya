package Sample;

public class EmpDetails {
	// Instance Variables
	public static void main(String[] args)
	{
		EmpDetails emp = new EmpDetails();
		emp.dispEmpID(46041886);
		emp.dispEmpName("Lakshmi Sravya");
		emp.dispEmpDesg("Analyst Trainee");
		emp.dispEmploc("Hyderabad");
		emp.dispEmpClassNo("TR04");
		System.out.println("Salary is "+calculate());
	}

	static double calculate()
	{
		return 300000/12;
	}

	void dispEmpID(long empID)
	{
		System.out.println("Employee's ID is "+empID);
	}
	void dispEmpName(String name)
	{
		System.out.println("Employee's name is "+name);
	}
	void dispEmpDesg(String desg)
	{
		System.out.println("Employee's designation is "+desg);
	}
	void dispEmploc(String loc)
	{
		System.out.println("Employee's location is "+loc);
	}
	void dispEmpClassNo(String num)
	{
		System.out.println("Employee's training room is "+num);
	}

}
