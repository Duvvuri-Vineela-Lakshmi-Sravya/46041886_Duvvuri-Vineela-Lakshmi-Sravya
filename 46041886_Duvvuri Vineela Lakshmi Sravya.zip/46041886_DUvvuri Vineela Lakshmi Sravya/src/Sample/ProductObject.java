package Sample;

public class ProductObject {

	private int productID;
	private String productName;
	private double price;
	
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "ProductObject [productID=" + productID + ", productName=" + productName + ", price=" + price + "]";
	}
	
	public static void main(String[] args)
	{
		ProductObject po=new ProductObject();
		ProductObject po1=new ProductObject();
		po.setProductID(123456);
		po1.setProductID(234567);
		po.setProductName("Rice");
		po1.setProductName("Sugar");
		po.setPrice(1250.0);
		po1.setPrice(50.0);
		
		System.out.println(po); // toString method
		System.out.println("The next item is "+po1.getProductName()+" with product ID "+po1.getProductID()+" having price "+po1.getPrice());
	}
}
