package Sample;

public enum EnumSample {
	
	JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC;

	EnumSample()  // Only Private constructor is valid.
	{
		System.out.println("This is enumerated data type");
	}
	
	void display() {
		int b=JAN.ordinal();  // We can access Enum costants directly. It gives error if we use EnumSample.JAN
		System.out.println(b);
	}
}
