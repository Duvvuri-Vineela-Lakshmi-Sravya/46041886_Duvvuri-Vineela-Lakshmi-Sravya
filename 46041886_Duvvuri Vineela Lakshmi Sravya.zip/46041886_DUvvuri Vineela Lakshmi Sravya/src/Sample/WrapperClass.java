package Sample;

public class WrapperClass {

	public void toConversion()
	{
		int a=3;
		double b=3.14;
		Integer aa=new Integer(a);
		System.out.println(aa);
		Double bb=new Double(b);
		System.out.println(bb);
		System.out.println(aa instanceof Integer);
		//System.out.println(a instanceof Integer);
		
		int c=aa.intValue();
		System.out.println(c);
		
		double d=bb.doubleValue();
		System.out.println(d);
		
	}
	public static void main(String[] args)
	{
		WrapperClass wc=new WrapperClass();
		wc.toConversion();
	}
}
