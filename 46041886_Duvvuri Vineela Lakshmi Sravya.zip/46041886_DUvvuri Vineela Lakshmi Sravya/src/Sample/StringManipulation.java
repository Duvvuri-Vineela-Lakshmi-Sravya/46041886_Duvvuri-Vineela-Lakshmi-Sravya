package Sample;
import java.util.*;

public class StringManipulation {
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name: ");
		String name=sc.nextLine();
		
		System.out.println("The length of your name is "+name.length());
		System.out.println("You are called as "+name.substring(7,14));
		if(name==null)      //what is dead code ?
			System.out.println("No name");
		else
			System.out.println("Good name !!!");
		String str="Hello java programming    ";
		System.out.println(str.trim());
		System.out.println(str.charAt(6));
		System.out.println(str.concat(name));
		char sample[]=str.toCharArray(); // converts string to character array
		for(char x:sample)
			System.out.print(" "+x);
		System.out.println(str.toLowerCase());
		System.out.println(str.toUpperCase());
		System.out.println(str.compareTo(name));
		
		sc.close();
	}
}
