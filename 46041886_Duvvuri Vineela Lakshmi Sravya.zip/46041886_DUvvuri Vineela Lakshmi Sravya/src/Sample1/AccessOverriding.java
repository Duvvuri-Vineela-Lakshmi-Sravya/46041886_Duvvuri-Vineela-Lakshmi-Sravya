package Sample1;

public class AccessOverriding extends Accover{
	//void show1() ----------- NO ERROR
	//protected void show1() ---------- NO ERROR
	// public void show1() ----------- NO ERROR
	private void show1()
	{
		System.out.println("Child class show 1");
	}
	//protected void show2() --------- NO ERROR
	// public void show2() ------------ NO ERROR
	// private void show2() -------------------------- VISIBILITY ERROR
	void show2()
	{
		System.out.println("Child class show 2");
	}
	protected void show3()
	{
		System.out.println("Child class show 3");
	}
	public void show4()
	{
		System.out.println("Child class show 4");
	}

}
class Accover{
	private void show1()
	{
		System.out.println("Parent class show 1");
	}
	void show2()
	{
		System.out.println("Parent class show 2");
	}
	protected void show3()
	{
		System.out.println("Parent class show 3");
	}
	public void show4()
	{
		System.out.println("Parent class show 4");
	}
}
