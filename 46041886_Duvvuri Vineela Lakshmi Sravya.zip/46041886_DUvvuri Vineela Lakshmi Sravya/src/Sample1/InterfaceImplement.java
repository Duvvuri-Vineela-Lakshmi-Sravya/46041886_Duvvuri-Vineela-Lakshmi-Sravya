package Sample1;

public class InterfaceImplement implements Inter3 {

	@Override
	public int addNum(int x, int y) {
		int z=x+y;
		return z;
	}

	@Override
	public float subNum(float x, float y) {
		float z=x+y;
		return z;
	}

	@Override
	public void mulNum(int x, int y) {
		int z=x*y;
		System.out.println(z);
	}

	public static void main(String[] args)
	{
		//System.out.println(Inter3.a);
		System.out.println(Inter1.a);
		System.out.println(Inter2.a);
		InterfaceImplement ii=new InterfaceImplement();
		System.out.println(ii.addNum(15, 25));
		System.out.println(ii.subNum(20f, 7f));
	}

}
