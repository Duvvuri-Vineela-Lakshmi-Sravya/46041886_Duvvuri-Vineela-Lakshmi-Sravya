package Sample1;

public interface Inter3 extends Inter1,Inter2{
	void mulNum(int x,int y);

}
