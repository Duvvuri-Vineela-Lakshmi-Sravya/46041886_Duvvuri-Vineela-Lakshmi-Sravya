package Sample1;

public class Distance {
	long speed=186000;
	
	public static void main(String[] args)
	{
		long distance;
		Distance d=new Distance();
		distance=d.speed*1000*24*60*60; // Inside static method, we have to create an object to access instance variable.
		System.out.println("The distance travelled by light is "+distance+ " meters.");
	}
	public void add()
	{
		long val=speed+10;  // instance variables can be accessed inside the class without object.
		System.out.println(val);
	}

}
