package Sample1;

public class B extends A{
	
	B()
	{
		super(3);
		System.out.println("This is constructor of sub-class");
	}
	public void method1()
	{
		System.out.println("This is the method1 of sub-class B");
	}
	public void method2()
	{
		System.out.println("This is the method2 of sub-class B");
	}
	
	public static void main(String[] args)
	{
		B b=new B();
		b.method1();
		b.method2();
		A a=new A();
		a.method1();
		A obj1=new B();
		obj1.method1();
		// obj1.method2(); Not valid.
		//B obj2= (B)new A(); It will be a warning because objects are created at runtime. We get errors only at compile time. DownCasting is not possible.
		//obj2.method1();
		//obj2.method2();
		
		// not possible -- B obj3= new A();
		
	}

}
