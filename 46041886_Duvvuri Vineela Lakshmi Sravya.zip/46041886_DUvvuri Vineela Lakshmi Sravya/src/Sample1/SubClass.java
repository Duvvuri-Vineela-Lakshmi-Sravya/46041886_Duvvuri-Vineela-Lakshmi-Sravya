package Sample1;

public class SubClass extends SuperClass {
	
	SubClass()
	{
		System.out.println("This is the constructor of sub-class");
	}
	public static void main(String[] args)
	{
		SubClass sc=new SubClass();
	}
}
 class SuperClass
{
	SuperClass()
	{
		System.out.println("This is the constructor of SuperClass");
	}
}
