package Sample1;

import java.util.Scanner;

public class SecondLargest {
	Scanner sc=new Scanner(System.in);
	int secLargest()
	{
		int num,i,max,temp,secLar,k=0;
		System.out.println("Enter the number of elements:");
		num=sc.nextInt();
		System.out.println("Enter the values: ");
		int[] vals=new int[num];
		for(i=0;i<num;i++)
			vals[i]=sc.nextInt();
		max=vals[0];
		for(i=1;i<num;i++)
		{
			if(max<vals[i])
			{
				max=vals[i];
				k=i;
			}
		}
		temp=vals[0];
		vals[0]=vals[k];
		vals[k]=temp;
		secLar=vals[1];
		for(i=2;i<num;i++) 
		{
			if(secLar<vals[i])
				secLar=vals[i];
		}
	return secLar;			
	}
	public static void main(String[] args)
	{
		SecondLargest sl=new SecondLargest();
		System.out.println("The second largest number is: "+sl.secLargest());
	}
}
