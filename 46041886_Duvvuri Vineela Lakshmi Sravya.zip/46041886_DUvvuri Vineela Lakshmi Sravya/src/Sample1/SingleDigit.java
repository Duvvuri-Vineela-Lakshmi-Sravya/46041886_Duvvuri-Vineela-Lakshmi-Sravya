package Sample1;

import java.util.Scanner;

public class SingleDigit {
	public void toCheck(int num)
	{
		if(num>0 && num<=9)
			System.out.println("Successfully entered a single digit number");
		else {
			try {
				DigitException de=new DigitException("It is not a single digit number.");
				throw de;
			}
			catch(DigitException d)
			{
				System.out.println(d);
			}
			finally {
				System.out.println("-------------- T H A N K Y O U --------------");
			}
		}
	}
	public static void main(String[] args)
	{
		SingleDigit sd=new SingleDigit();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a single digit number: ");
		int num=sc.nextInt();
		sd.toCheck(num);
		sc.close();
	}
}
