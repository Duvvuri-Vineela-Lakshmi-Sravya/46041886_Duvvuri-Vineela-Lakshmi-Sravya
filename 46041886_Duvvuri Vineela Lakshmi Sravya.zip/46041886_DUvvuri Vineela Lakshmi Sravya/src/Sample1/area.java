package Sample1;

public abstract class area {
	
	//constructor
	
	area()
	{
		System.out.println("This is an abstract class");
	}
	
	//abstract method
	public abstract void CalculateArea();

}
