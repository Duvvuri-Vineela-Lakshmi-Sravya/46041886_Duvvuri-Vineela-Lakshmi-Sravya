package Sample1;

public class A {
	int val;

	A()
	{
		System.out.println("this is the constructor of super class");
	}
	A(int val)
	{
		this.val=val;
		System.out.println("The value is "+val);
	}
	public void method1()
	{
		System.out.println("This is the method1 of super class A");
	}
}

