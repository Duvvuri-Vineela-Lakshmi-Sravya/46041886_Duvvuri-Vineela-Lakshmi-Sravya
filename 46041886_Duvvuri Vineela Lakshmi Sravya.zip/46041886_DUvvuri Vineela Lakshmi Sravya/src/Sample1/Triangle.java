package Sample1;

import java.util.Scanner;

public class Triangle extends area {
	Scanner sc=new Scanner(System.in);
	
	int base,height;

	@Override
	public void CalculateArea() {
		System.out.println("Enter base of triangle: ");
		base=sc.nextInt();
		System.out.println("Enter height of triangle: ");
		height=sc.nextInt();
		System.out.println("Area is: "+(0.5*base*height));
	}
	
	public static void main(String[] args)
	{
		Triangle tr=new Triangle();
		tr.CalculateArea();
	}
	

}
