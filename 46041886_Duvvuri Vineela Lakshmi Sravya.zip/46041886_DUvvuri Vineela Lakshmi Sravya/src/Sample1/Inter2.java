package Sample1;

public interface Inter2 {
	int a=20,b=10;
	float subNum(float x, float y);

}
