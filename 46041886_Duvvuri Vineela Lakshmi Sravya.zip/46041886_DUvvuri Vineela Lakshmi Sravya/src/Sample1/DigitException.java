package Sample1;

public class DigitException extends Exception {
	final String str1="It is not a single digit number.";
	DigitException()
	{
		System.out.println(str1);
	}
	
	DigitException(String str1)
	{
		super(str1);
	}
}
