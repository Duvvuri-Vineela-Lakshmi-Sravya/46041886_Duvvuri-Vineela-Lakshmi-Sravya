package Sample1;

public class SubClass1 extends SuperClass1 {
	
	int varSub=10, mtdSub=20;
	public static void main(String[] args)
	{
		SubClass1 sc=new SubClass1();
		System.out.println(sc.mtdSub);
		System.out.println(sc.disp());
	}
	
	int disp()
	{
		System.out.println(super.varSuper);
		return super.display();
		
	}

}
class SuperClass1
{
	int varSuper=30,mtdSuper=40;
	int display()
	{
		return mtdSuper;
	}
}