package Sample1;

public class ExceptionOverriding extends ExceptOver {
	
	public void method1() throws IOException // This is checked exception   ------------- ERROR (When throws is not used in parent class.)
	//public void method1() throws Exception     ------------------------------------------ ERROR
	//public void method1() throws ArithmeticException  // This is an unchecked exception  (When parent class throws Exception) AE is subclass
	{
		try
		{
			int n=10/0;
			System.out.println(n);                                               // We can define try catch in empty blocks also.
		}
		catch(ArithmeticException | NullPointerException ex)
		//catch(ArithmeticException|IOException ex) -------- ERROR
		{
			System.out.println("This is the error associated with child class.");
		}
		catch(IOException io)
		{
			System.out.println("IO Exception of child class");
		}
	}
	public static void main(String[] args)
	{
		ExceptionOverriding eo=new ExceptionOverriding();
		eo.method1();
	}
}
class ExceptOver
{
	String name;
	public void method1() throws Exception
	//public void method1() throws NullpointerException
	{
		try {
		System.out.println(name);
		}
		catch(Exception e){
			System.out.println("Exception of parent class");
		}
	}
}