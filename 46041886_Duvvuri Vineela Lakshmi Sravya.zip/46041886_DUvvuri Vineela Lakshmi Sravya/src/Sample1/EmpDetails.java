package Sample1;

import java.util.*;

public class EmpDetails {
	String name,city;  // line 6 and line 7 are optional.
	float sal;
	
	EmpDetails(String name, String city, float sal)
	{
		System.out.println(name);
		System.out.println(city);
		System.out.println(sal);
	}
	Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter name: ");
		String name=sc.next();
		System.out.println("Enter city: ");
		String city=sc.next();
		System.out.println("Enter salary: ");
		float sal=sc.nextFloat();
		EmpDetails emp=new EmpDetails(name,city,sal);
	}
	

}
