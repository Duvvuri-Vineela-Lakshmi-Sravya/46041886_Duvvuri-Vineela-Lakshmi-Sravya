package Sample1;

import java.util.Scanner;

public class MovieTickets {
	
	private String name, movieName, seatno, place;
	private float price;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getSeatno() {
		return seatno;
	}
	public void setSeatno(String seatno) {
		this.seatno = seatno;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "MovieTickets [name=" + name + ", movieName=" + movieName + ", seatno=" + seatno + ", place=" + place
				+ ", price=" + price + "]";
	}

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		MovieTickets mt=new MovieTickets();
			System.out.println("Enter name: ");
			String name=sc.next();
			mt.setName(name);
			System.out.println("Enter place: ");
			String place=sc.next();
			mt.setPlace(place);
			System.out.println("Enter movie name: ");
			String movie=sc.next();
			mt.setMovieName(movie);
			System.out.println("Enter seatno: ");
			String seat=sc.next();
			mt.setSeatno(seat);
			System.out.println("Enter price: ");
			int price=sc.nextInt();
			mt.setPrice(price);
	
		/*	System.out.println(mt.getMovieName());
			System.out.println(mt.getName());
			System.out.println(mt.getSeatno());
			System.out.println(mt.getPlace());
			System.out.println(mt.getPrice()); */
			
			System.out.println(mt.toString());
	}
}
