package Sample1;

public class overloading {

	public void add(int a, int b)
	{
		int c=a+b;
		System.out.println(c);
	}
	public void add(float a, float b)
	{
		System.out.println(a+b);
	}
	public void add(float a, int b)
	{
		System.out.println(a+b);
	}
	
	public static void main(String[] args)
	{
		overloading ol1=new overloading();
	
		ol1.add(2, 3);
		ol1.add(2.3f, 4.5f);
		ol1.add(4.5f, 9);
	}

}
