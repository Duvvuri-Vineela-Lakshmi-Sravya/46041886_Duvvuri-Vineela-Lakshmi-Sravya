package Sample1;

public interface Inter1 {
	int a=10,b=20;
	int addNum(int x,int y);

}
