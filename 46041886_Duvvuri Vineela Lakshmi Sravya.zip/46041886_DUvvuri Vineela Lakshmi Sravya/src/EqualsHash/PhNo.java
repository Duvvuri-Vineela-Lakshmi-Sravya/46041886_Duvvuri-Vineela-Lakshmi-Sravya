package EqualsHash;

public class PhNo {
	
	private int phNo;
	public PhNo() {
		this.phNo=(int)(Math.random()*10000);
	}
	public int getPhNo() {
		return phNo;
	}
	public void setPhNo(int phNo) {
		this.phNo= phNo;
	}
}