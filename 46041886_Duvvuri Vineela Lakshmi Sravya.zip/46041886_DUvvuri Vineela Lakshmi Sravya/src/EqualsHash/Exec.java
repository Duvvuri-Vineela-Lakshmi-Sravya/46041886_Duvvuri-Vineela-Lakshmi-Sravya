package EqualsHash;

import java.util.HashMap;
import java.util.Map;

public class Exec {
	
	public static void main(String[] args)
	{
		Person p1=new Person("Sravya");
		Person p2=new Person("Sravya");
		System.out.println(p1.equals(p2));
		Map<Person,PhNo>contact=new HashMap<Person,PhNo>();
		contact.put(p1,new PhNo());
		contact.put(p2,new PhNo());
		
		System.out.println(contact.size());
	}

}
