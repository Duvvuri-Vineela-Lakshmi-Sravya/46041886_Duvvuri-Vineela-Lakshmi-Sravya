package EqualsHash;

public class Person {
	
	private String name;
	
	Person(String name)
	{
		this.name=name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public boolean equals(Object obj)
	{
		if(obj!=null && obj instanceof Person)
		{
			String name1=((Person)obj).getName();
			if(name1!=null && name1.equals(this.getName()))
			{
				return true;
			}
		}
		return false;		
	}
	public int hashCode()
	{
		return this.name.hashCode();
	}
	

}
