package com.cg.eis.service;

public interface EmployeeService {
	public void getEmpDet();
	public String insScheme(float sal);
	public void dispEmp();
}
