package lab2;

import java.util.Scanner;

public class Exercise1 {
	Scanner sc=new Scanner(System.in);
	int secSmallest()
	{
		int num,i,max,temp,secSmall,k=0;
		System.out.println("Enter the number of elements:");
		num=sc.nextInt();
		System.out.println("Enter the values: ");
		int[] vals=new int[num];
		for(i=0;i<num;i++)
			vals[i]=sc.nextInt();
		max=vals[0];
		for(i=1;i<num;i++)
		{
			if(max>vals[i])
			{
				max=vals[i];
				k=i;
			}
		}
		temp=vals[0];
		vals[0]=vals[k];
		vals[k]=temp;
		secSmall=vals[1];
		for(i=2;i<num;i++) 
		{
			if(secSmall>vals[i])
				secSmall=vals[i];
		}
	return secSmall;			
	}
	public static void main(String[] args)
	{
		Exercise1 e=new Exercise1();
		System.out.println("The second smallest number is: "+e.secSmallest());
	}
}
