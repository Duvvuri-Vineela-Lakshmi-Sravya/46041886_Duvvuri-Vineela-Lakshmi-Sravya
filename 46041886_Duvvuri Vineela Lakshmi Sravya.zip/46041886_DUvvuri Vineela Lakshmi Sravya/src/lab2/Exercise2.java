package lab2;

import java.util.Scanner;

public class Exercise2 {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of names: ");
		int n=sc.nextInt();
		String[] names=new String[n];
		System.out.println("Enter names: ");
		for(int i=0;i<n;i++)
			names[i]=sc.next();
		stringManip(names,n);
		sc.close();
	}
	public static void stringManip(String[] names,int n)
	{
		String temp=null;
		int i,j;
		for(i=0;i<n-1;i++)
		{
			for(j=0;j<n-i-1;j++)
			{
				if(names[j].compareTo(names[j+1])>0)
				{
					temp=names[j];
					names[j]=names[j+1];
					names[j+1]=temp;
				}
			}
		}
		if(n%2==0)
		{
			for(i=0;i<n/2;i++)
				System.out.println(names[i].toUpperCase());
			for(i=n/2;i<n;i++)
				System.out.println(names[i].toLowerCase());
		}
		else
		{
			for(i=0;i<(n/2)+1;i++)
				System.out.println(names[i].toUpperCase());
			for(i=(n/2)+1;i<n;i++)
				System.out.println(names[i].toLowerCase());
		}
	}
}
