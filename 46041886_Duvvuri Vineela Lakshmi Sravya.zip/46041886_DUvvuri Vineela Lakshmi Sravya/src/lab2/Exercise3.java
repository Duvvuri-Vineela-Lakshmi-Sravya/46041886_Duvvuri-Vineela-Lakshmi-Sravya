package lab2;

import java.util.Scanner;

public class Exercise3 {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of elements");
		int n=sc.nextInt();
		int[] ar=new int[n];
		System.out.println("Enter elements");
		for(int i=0;i<n;i++)
		{
			ar[i]=sc.nextInt();
			ar[i]=reverseNum(ar[i]);
		}
		int[] arr=sorted(ar,n);
		for(int i=0;i<n;i++)
		{
			System.out.println(arr[i]+" ");
		}
		sc.close();
	}
	public static int reverseNum(int num)
	{
		String str=Integer.toString(num);
		StringBuilder sb=new StringBuilder(str);
		String str1=sb.reverse().toString();
		return Integer.parseInt(str1);
	}
	public static int[] sorted(int[] ar,int n)
	{
		int temp,i,j;
		for(i=0;i<n-1;i++)
		{
			for(j=0;j<n-i-1;j++)
			{
				if(ar[j]>ar[j+1])
				{
					temp=ar[j];
					ar[j]=ar[j+1];
					ar[j+1]=temp;
				}
			}
		}
		return ar;
	}

}
