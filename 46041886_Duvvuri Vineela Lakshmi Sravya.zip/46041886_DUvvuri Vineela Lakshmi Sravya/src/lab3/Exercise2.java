package lab3;

public class Exercise2 {
	public static void main(String[] args) {  
        StringBuffer sb = new StringBuffer("programming");  
        System.out.println(sb+" | "+sb.reverse()); 
  
    }  

}

