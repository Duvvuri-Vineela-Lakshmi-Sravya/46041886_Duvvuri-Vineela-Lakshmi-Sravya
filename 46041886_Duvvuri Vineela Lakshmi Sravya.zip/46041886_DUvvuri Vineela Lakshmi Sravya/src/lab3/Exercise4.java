package lab3;

import java.util.Scanner;

public class Exercise4 {
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		int num=sc.nextInt();
		String str=Long.toString(num,10);
		String value="";
		for(int i=0;i<str.length()-1;i++)
		{
			int n=str.charAt(i)-str.charAt(i+1);
			value=value+Math.abs(n);
		}
		value=value+str.charAt(str.length()-1);
		int num1=Integer.parseInt(value);
		System.out.println(num1);
		sc.close();
	}

}
