package Lab1;

import java.util.*;

public class Exercise8 {
	
	public boolean checkNumber(int n)
	{
		int i,a;
		for(i=0;i<=15;i++)
		{
			a=(int) Math.pow(2, i);
			if(n==a)
			{
				return true;
			}
		}
		return false;
	}
	public static void main(String[] args)
	{
		Exercise8 e8=new Exercise8();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number: ");
		int num=sc.nextInt();
		System.out.println("Number is power of 2:"+e8.checkNumber(num));
		sc.close();
	}

}
