package Lab1;

import java.util.Scanner;

public class Exercise7 {

	public boolean IncreaseNumber(int n)
	{
		int a=n%10,b;
		n=n/10;
		boolean flag=true;
		while(n>0)
		{
			b=n%10;
			if(a>b)
			{
				a=b;
				n=n/10;
				b=n%10;
				flag=true;
			}
			else
			{
				flag=false;
				break;
			}
		}
		return flag;	
	}
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number: ");
		int num=sc.nextInt();
		Exercise7 e7=new Exercise7();
		System.out.println("Increasing Number: "+e7.IncreaseNumber(num));
		sc.close();
	}

}
