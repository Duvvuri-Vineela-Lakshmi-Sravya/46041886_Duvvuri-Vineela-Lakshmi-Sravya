package Lab1;

import java.util.Scanner;

public class Exercise6 {
	public void CalculateDifference(int n)
	{
		long sum1=0,sum2=0;
		int i;
		for(i=1;i<=n;i++)
		{
			sum1=sum1+(i*i);
			sum2=sum2+i;
		}
		System.out.println("The difference is "+((sum2*sum2)-sum1));
	}
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number: ");
		int num=sc.nextInt();
		Exercise6 e6=new Exercise6();
		e6.CalculateDifference(num);
		sc.close();
		
	}
}
