package Lab1;

import java.util.Scanner;

public class Exercise4 {
	public static void main(String[] args)
	{
		int i,j;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number: ");
		int num=sc.nextInt();
		System.out.println("The prime numbers are: ");
		for(i=1;i<=num;i++)
		{
			int count=0;
			for(j=1;j<=num;j++)
			{
				if(i%j==0)
					count++;				
			}	
			if(count==2)
				System.out.println(i+" ");
		}
	}
}
