package Lab1;

import java.util.Scanner;

public class Exercise5 {
	public void calc(int n)
	{
		int i;
		for(i=1;i<=n;i++)
		{
			if(i%3==0 ||i%5==0)
				System.out.print(i+" ");
		}
	}
	public static void main(String[] args)
	{
		Exercise5 e5=new Exercise5();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number: ");
		int num=sc.nextInt();
		e5.calc(num);
		sc.close();
	}

}
