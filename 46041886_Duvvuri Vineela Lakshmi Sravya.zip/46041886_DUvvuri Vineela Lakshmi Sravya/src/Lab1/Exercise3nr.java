package Lab1;

import java.util.Scanner;

public class Exercise3nr {
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number: ");
		int num=sc.nextInt();
		int a=0,b=1,c,i;
		System.out.println("Fibonacci series:");
		System.out.print(a+" "+b);
		for(i=2;i<num;i++)
		{
			c=a+b;
			System.out.print(" "+c);
			a=b;
			b=c;
		}
		sc.close();
		
	}

}
