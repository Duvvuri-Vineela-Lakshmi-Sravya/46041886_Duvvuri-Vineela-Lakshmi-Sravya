package Lab1;

import java.util.Scanner;

public class Exercise1 {
	long calc(int n)
	{
		long cubeval=0;
		while(n>0)
		{
			int a=n%10;
			cubeval=cubeval+(a*a*a);
			n=n/10;	
		}
		return cubeval;
	}
	public static void main(String[] args)
	{
		Exercise1 e1=new Exercise1();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int num=sc.nextInt();
		System.out.println("The value is "+e1.calc(num));
		sc.close();
	}

}
