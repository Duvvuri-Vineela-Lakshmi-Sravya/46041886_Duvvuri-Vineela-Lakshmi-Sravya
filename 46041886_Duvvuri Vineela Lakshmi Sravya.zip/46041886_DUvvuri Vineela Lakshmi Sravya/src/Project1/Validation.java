package Project1;

public class Validation {
	
	static boolean validName(String name)
	{
		if(name.matches( "[A-Z]{1}[a-z]{2,}$" ))
		{
			return true;
		}
		else
			return false;
	}
	
	static boolean validAmt(double amount)
	{
		if(amount>1000)
			return true;
		else
			return false;
	}
	
	static boolean validQuant(int qty)
	{
		if(qty>0)
			return true;
		else
			return false;
	}

}
