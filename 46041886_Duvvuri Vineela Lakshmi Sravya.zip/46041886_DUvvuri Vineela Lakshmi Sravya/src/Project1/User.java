package Project1;

import java.util.Scanner;

import java.util.*;

public class User {
	static int count=0;

	public static void main(String[] args)
	{
		int ch;
		Scanner sc=new Scanner(System.in);
		ArrayList<Entity> mobCollect=new ArrayList<Entity>();
		do
		{
			System.out.println("1. Add collection");
			System.out.println("2. Delete collection");
			System.out.println("3. Display collection");
			System.out.println("4. Exit");
			System.out.println("Enter your choice:");
			ch=sc.nextInt();
			switch(ch)
			{
			case 1: if(count>3)
					{
						try {
							CollectionOverload co=new CollectionOverload("Cannot add more than 3 collections");
							throw co;
						}
						catch(CollectionOverload c)
						{
							System.out.println(c);
						}
					}
					else {
					Entity e=new Entity();
					System.out.println("Enter first name:");
					String fname=sc.next();
					if(Validation.validName(fname))
						e.setFname(fname);
					else {
						System.out.println("Doesn't match the required pattern");
						break;
					}
					System.out.println("Enter last name:");
					String lname=sc.next();
					if(Validation.validName(lname))
						e.setLname(lname);
					else {
						System.out.println("Doesn't match the required pattern");
						break;
					}
					System.out.println("Enter mobile brand");
					String brand=sc.next();
					e.setMobBrand(brand);
					System.out.println("Enter price:");
					double price=sc.nextDouble();
					if(Validation.validAmt(price))
						e.setPrice(price);
					else {
						System.out.println("Price should be above 1000.0");
						break;
					}
					System.out.println("Enter quantity:");
					int qty=sc.nextInt();
					if(Validation.validQuant(qty))
						e.setQty(qty);
					else {
						System.out.println("Quantity should be greater than or equal to 1");
						break;
					}
					mobCollect.add(e);
					count++;
					}
					break;
			case 2: System.out.println("Enter mobile brand name to delete that collection:");
					String bname=sc.next();
					int flag=0;
					for(int i=0;i<mobCollect.size();i++)
					{
						String comp=mobCollect.get(i).getMobBrand();
						if(comp.equals(bname)) {
							count--;
							mobCollect.remove(i);
							flag=1;         //--------------------------------- to show that the element has been found and deleted.
						}
					}
					if(flag==1)
						System.out.println("The collection with brand name "+bname+" removed successfully.");
					else
						System.out.println("Collection Unavailable");
		
					break;
			case 3: System.out.println("Your Collection is ");
					for(int i=0;i<mobCollect.size();i++)
					{
						System.out.println(mobCollect.get(i));
					}
					break;
			case 4: System.out.println("Thank you for using the application");
					System.exit(0);
			}
		}while(ch!=4);
		sc.close();
	}
}
