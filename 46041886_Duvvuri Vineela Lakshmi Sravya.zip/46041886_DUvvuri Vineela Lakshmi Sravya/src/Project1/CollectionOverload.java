package Project1;

public class CollectionOverload extends Exception {
CollectionOverload()
{
	System.out.println("Cannot add more than 3 elements");
}
CollectionOverload(String message)
{
	super(message);
}
}
